#!/bin/bash
export LD_LIBRARY_PATH=".:$LD_LIBRARY_PATH"
./hltv +connect $1 -port $2 +exec hltv.cfg